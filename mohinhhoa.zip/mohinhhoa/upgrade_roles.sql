USE hoa_ma_toan_crm;

-- Allow application-defined roles such as manager without future ENUM migrations.
ALTER TABLE users
  MODIFY COLUMN role VARCHAR(50) NOT NULL DEFAULT 'student';
