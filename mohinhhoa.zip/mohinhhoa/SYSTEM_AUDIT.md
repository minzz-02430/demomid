# System audit and change log

Last reviewed: 2026-11-09

## Summary

The backend API modules and standalone demo frontend can run independently, but the project is not yet a fully integrated application. The frontend still uses browser-only demo data. The live MySQL schemas were checked on 2026-11-09; `hoa_ma_toan_crm` matches the 18-table current schema, while `hoa_ma_toan` remains a legacy schema with incompatible CRM tables.

## Work recorded from the project sessions

### Database scaffold

- Created `database_production.sql` as the single fresh-install initializer from the current DBML and upgrade definitions.
- Added tables for users, students, parent/student links, courses, classes, schedules, enrollments, attendance reports, assignments/submissions, grades, invoices/payments, leads, and support tickets.
- Added enum statuses, keys, foreign keys, and delete/update rules.

### Express and MySQL scaffold

- Replaced the initial root-only Express sample with JSON and URL-encoded body parsing, CORS, a global error handler, and `GET /api/v1/health`.
- Added a `mysql2/promise` connection pool and connection-check logging.

### Authentication

- Added JWT authentication and role middleware.
- Added `POST /api/v1/auth/register` and `POST /api/v1/auth/login`.
- Registration validates inputs, hashes passwords with bcryptjs at 10 salt rounds, checks for duplicate email, and does not permit public admin registration.
- Login compares password hashes and issues seven-day JWTs.

### Sales and CRM

- Added admin/sales lead creation and a sales-only assigned lead queue.
- Added admin/sales contract creation with generated unique contract codes.

### Finance

- Added accountant/admin invoice creation using a database transaction, contract row locking, amount validation, and contract payment-state updates.
- Added an admin-only current-month revenue summary.
- Added `contracts.paid_amount` to the canonical schema and a one-time migration to backfill it from existing invoices.

### Support

- Added parent/student request submission and admin/manager pending-request review and status updates.
- Changed user role storage to `VARCHAR(50)` in the canonical schema and added `upgrade_roles.sql` for existing databases.

### Reports

- Added tutor-only `POST /api/v1/reports/session` and parent-only `GET /api/v1/reports/my-children`.
- A report identifies one enrollment and lesson date, validates tutor/class/schedule ownership, and returns child reports through the parent/student relationship.
- The subject label is selected from `courses.name`, because the schema has no `classes.subject` column.

## Changes made during this audit

- Rechecked the API and found that contract creation accepted `paid` or `partially_paid` without recording an invoice. New contracts now always use the schema's `unpaid` default; attempts to set `paymentStatus` directly return HTTP 400, with a regression test.
- Replaced the placeholder `npm test` command with Node's built-in test runner and added `test/system.test.js` to exercise health, registration/password hashing, login/JWT, report creation, and parent access control using a mocked MySQL pool.
- Added dotenv loading and `.env.example`; no real `.env` or credentials were created.
- Updated `db.dbml` to represent all tables and role/status relationships from `database_production.sql`.
- Consolidated the full schema into `database_production.sql` for `hoa_ma_toan_crm`, with database creation and selection as its first two SQL statements.
- Extended the schema to 18 tables, adding CRM `contracts`, `tasks`, and `customer_requests`; synchronized the six user roles and the requested attendance/customer-request status enums.
- Kept attendance-report uniqueness at `(enrollment_id, schedule_id, lesson_date)` so a student can have reports for different classes on the same day.
- `upgrade_roles.sql` widens `users.role` to `VARCHAR(50)` only; it does not normalize legacy role values or alter `username`/`email`, so those changes remain a migration preflight requirement.
- Live schema check: `hoa_ma_toan_crm` has all 18 tables, `users.role VARCHAR(50) DEFAULT 'student'`, `contracts.paid_amount`, and CRM foreign keys to `users`, `classes`, `students`, and `contracts`; MariaDB version is 10.4.32.
- Live legacy-schema check: `hoa_ma_toan` has 15 tables, `users.role ENUM('admin','teacher','parent')`, legacy `leads` columns (`name`, legacy statuses), and `invoices` columns (`student_id`, `period`, legacy status) with no `contracts` table. It is not compatible with the current API and is not changed by the new fresh-install script.
- Confirmed `db.dbml` defines 18 tables, not 15; all 18 are included in `database_production.sql`.
- Clarified in `README.md` that the browser demo is not connected to the backend and documented backend setup.

## Verification performed

- Recheck on 2026-11-09: `npm test` passed; `node --check` passed for all 19 application/source/test JavaScript files; dashboard `npm run build` and `npm run lint` passed; `npm audit --omit=dev` reported zero vulnerabilities.
- Connected to MySQL and inspected schema metadata for both `hoa_ma_toan_crm` and `hoa_ma_toan`; no row contents were queried or modified.
- Contract creation regression: explicit `paymentStatus: "paid"` is rejected; default newly created contract status remains `unpaid`.
- Browser smoke test: demo login on `test.html` opened the dashboard; switching the demo role to tutor and parent rendered their corresponding views.
- API smoke check: health returned 200; invalid registration returned 400; protected reports without a token returned 401.
- SQL report queries were checked against MariaDB 10.4.32 metadata using `EXPLAIN`; the parent report join parsed successfully.

These checks do **not** prove application writes against a seeded live database: API tests mock the pool, and the Node app's local connection settings currently point to localhost:3306 while the inspected database is available through the configured database tool. The fresh-install SQL has not been run against a disposable schema in this session; live metadata was inspected read-only.

## Outstanding blockers and scope gaps

1. **Existing database migration is still required and unverified.** `hoa_ma_toan` has a legacy `users.role` enum (`admin`, `teacher`, `parent`), required `username`, nullable `email`, and old `leads`/`invoices` shapes. `database_production.sql` is a fresh initializer for `hoa_ma_toan_crm`, not an in-place migration. Back up and migrate existing data separately before switching traffic.
2. **The Node application has no working database connection in the current environment.** No `.env` exists, and the application's configured local connection fails because MySQL is not listening on localhost:3306. The database-tool connection used for read-only inspection is separate. Configure the app's DB settings and a strong random `JWT_SECRET` in `.env`, then verify its own connection.
3. **Frontend and backend are separate.** `test.html` embeds its own CSS/JavaScript and uses demo accounts/local browser data; it does not load `portal.js` or `style.css`, and it does not call auth/report APIs. The pages can be demonstrated but do not reflect database-backed behavior.
4. **Report scope is incomplete.** The current report API persists attendance and a tutor comment, but not a per-session score or a student response. The described student-feedback workflow has no endpoint or storage field yet.
5. **Student account/profile linkage is incomplete.** Public registration can create a `student` user, but does not create/link a row in `students`; `parent_student` links parents to student profiles, and no API for creating that link is present.
6. **Tutor registration is self-service.** Any registrant may request the `tutor` role; there is no invitation or approval workflow. Restrict or approve tutor accounts before enabling real data access.
7. **This is not the full planned backend.** Auth, reports, sales, and finance are the implemented business API modules. Invoice creation and monthly revenue are implemented, but general CRUD APIs for classes, schedules, enrollments, payments, assignments, and support tickets are not. The frontend's branch-manager role also has no matching backend/database role.
8. **Existing data needs migration preflight.** Before moving legacy records into the new schema, resolve missing/duplicate emails and map old roles and attendance statuses. Set `DB_NAME=hoa_ma_toan_crm` to match the initializer.

## Known routes

- `GET /api/v1/health`
- `POST /api/v1/auth/register`
- `POST /api/v1/auth/login`
- `POST /api/v1/reports/session`
- `GET /api/v1/reports/my-children`
- `POST /api/v1/sales/leads`
- `GET /api/v1/sales/leads/my-queue`
- `POST /api/v1/sales/contracts`
- `POST /api/v1/finance/invoices`
- `GET /api/v1/finance/dashboard/revenue`
- `POST /api/v1/support/requests`
- `GET /api/v1/support/requests/pending`
- `PATCH /api/v1/support/requests/:id/status`

The root path `/` is not a frontend host route in the current API app. Open `test.html` directly for the separate demo.
