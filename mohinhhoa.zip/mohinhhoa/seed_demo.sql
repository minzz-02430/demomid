CREATE DATABASE IF NOT EXISTS hoa_ma_toan_crm
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE hoa_ma_toan_crm;

-- Idempotent demo data for database_production.sql (18 tables).
-- This file does not truncate tables or disable foreign-key checks.
-- Demo accounts all use: Demo123456! Change these before exposing the app.
START TRANSACTION;

-- 1. Users: administration, operations, tutors, parents, and students.
INSERT INTO users (role, name, username, email, phone, password_hash)
VALUES
  ('admin', 'Nguyễn Minh Anh', 'demo.admin', 'demo.admin@hoamatoan.vn', '0901000001', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('manager', 'Trần Thu Hà', 'demo.manager', 'demo.manager@hoamatoan.vn', '0901000002', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('sales', 'Lê Quốc Bảo', 'demo.sales', 'demo.sales@hoamatoan.vn', '0901000003', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('accountant', 'Phạm Ngọc Lan', 'demo.accountant', 'demo.accountant@hoamatoan.vn', '0901000004', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('tutor', 'Nguyễn Hoàng Long', 'demo.tutor.long', 'demo.tutor.long@hoamatoan.vn', '0901000005', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('tutor', 'Đỗ Thanh Mai', 'demo.tutor.mai', 'demo.tutor.mai@hoamatoan.vn', '0901000006', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('tutor', 'Vũ Đức Minh', 'demo.tutor.minh', 'demo.tutor.minh@hoamatoan.vn', '0901000007', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('parent', 'Nguyễn Thu Hương', 'demo.parent.huong', 'demo.parent.huong@hoamatoan.vn', '0902000001', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('parent', 'Trần Văn Nam', 'demo.parent.nam', 'demo.parent.nam@hoamatoan.vn', '0902000002', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('parent', 'Lê Thị Mai', 'demo.parent.mai', 'demo.parent.mai@hoamatoan.vn', '0902000003', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('student', 'Nguyễn Gia An', 'demo.student.an', 'demo.student.an@hoamatoan.vn', '0903000001', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('student', 'Nguyễn Minh Bình', 'demo.student.binh', 'demo.student.binh@hoamatoan.vn', '0903000002', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('student', 'Trần Bảo Chi', 'demo.student.chi', 'demo.student.chi@hoamatoan.vn', '0903000003', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('student', 'Lê Hoàng Duy', 'demo.student.duy', 'demo.student.duy@hoamatoan.vn', '0903000004', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('student', 'Phạm Khánh Linh', 'demo.student.linh', 'demo.student.linh@hoamatoan.vn', '0903000005', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6'),
  ('student', 'Vũ Đức Khoa', 'demo.student.khoa', 'demo.student.khoa@hoamatoan.vn', '0903000006', '$2b$10$PVFcEl2YjEGYIbZTpJwMI.rcz/s91Cl8Z/tbsz1Olhd3P8bL69qG6')
ON DUPLICATE KEY UPDATE
  role = VALUES(role),
  name = VALUES(name),
  phone = VALUES(phone),
  password_hash = VALUES(password_hash);

-- Student login users and student profiles are separate in this schema.
INSERT INTO students (name, grade, date_of_birth, notes)
SELECT 'Nguyễn Gia An', '6', '2014-03-12', 'SEED_DEMO:student:an'
WHERE NOT EXISTS (SELECT 1 FROM students WHERE notes = 'SEED_DEMO:student:an');
INSERT INTO students (name, grade, date_of_birth, notes)
SELECT 'Nguyễn Minh Bình', '6', '2014-08-25', 'SEED_DEMO:student:binh'
WHERE NOT EXISTS (SELECT 1 FROM students WHERE notes = 'SEED_DEMO:student:binh');
INSERT INTO students (name, grade, date_of_birth, notes)
SELECT 'Trần Bảo Chi', '9', '2011-01-17', 'SEED_DEMO:student:chi'
WHERE NOT EXISTS (SELECT 1 FROM students WHERE notes = 'SEED_DEMO:student:chi');
INSERT INTO students (name, grade, date_of_birth, notes)
SELECT 'Lê Hoàng Duy', '7', '2013-06-08', 'SEED_DEMO:student:duy'
WHERE NOT EXISTS (SELECT 1 FROM students WHERE notes = 'SEED_DEMO:student:duy');
INSERT INTO students (name, grade, date_of_birth, notes)
SELECT 'Phạm Khánh Linh', '10', '2010-10-30', 'SEED_DEMO:student:linh'
WHERE NOT EXISTS (SELECT 1 FROM students WHERE notes = 'SEED_DEMO:student:linh');
INSERT INTO students (name, grade, date_of_birth, notes)
SELECT 'Vũ Đức Khoa', '6', '2014-05-04', 'SEED_DEMO:student:khoa'
WHERE NOT EXISTS (SELECT 1 FROM students WHERE notes = 'SEED_DEMO:student:khoa');

-- 2. Parent-to-student relationships (one parent may have multiple children).
INSERT INTO parent_student (parent_id, student_id, relationship)
SELECT p.id, s.id, 'mother'
FROM users p CROSS JOIN students s
WHERE p.email = 'demo.parent.huong@hoamatoan.vn' AND s.notes = 'SEED_DEMO:student:an'
ON DUPLICATE KEY UPDATE relationship = VALUES(relationship);
INSERT INTO parent_student (parent_id, student_id, relationship)
SELECT p.id, s.id, 'mother'
FROM users p CROSS JOIN students s
WHERE p.email = 'demo.parent.huong@hoamatoan.vn' AND s.notes = 'SEED_DEMO:student:binh'
ON DUPLICATE KEY UPDATE relationship = VALUES(relationship);
INSERT INTO parent_student (parent_id, student_id, relationship)
SELECT p.id, s.id, 'father'
FROM users p CROSS JOIN students s
WHERE p.email = 'demo.parent.nam@hoamatoan.vn' AND s.notes = 'SEED_DEMO:student:chi'
ON DUPLICATE KEY UPDATE relationship = VALUES(relationship);
INSERT INTO parent_student (parent_id, student_id, relationship)
SELECT p.id, s.id, 'mother'
FROM users p CROSS JOIN students s
WHERE p.email = 'demo.parent.mai@hoamatoan.vn' AND s.notes = 'SEED_DEMO:student:duy'
ON DUPLICATE KEY UPDATE relationship = VALUES(relationship);
INSERT INTO parent_student (parent_id, student_id, relationship)
SELECT p.id, s.id, 'mother'
FROM users p CROSS JOIN students s
WHERE p.email = 'demo.parent.mai@hoamatoan.vn' AND s.notes = 'SEED_DEMO:student:linh'
ON DUPLICATE KEY UPDATE relationship = VALUES(relationship);
INSERT INTO parent_student (parent_id, student_id, relationship)
SELECT p.id, s.id, 'father'
FROM users p CROSS JOIN students s
WHERE p.email = 'demo.parent.nam@hoamatoan.vn' AND s.notes = 'SEED_DEMO:student:binh'
ON DUPLICATE KEY UPDATE relationship = VALUES(relationship);

-- 3. Courses and classes. Marker text keeps these rows identifiable on reruns.
INSERT INTO courses (name, description, fee)
SELECT 'Toán nền tảng khối 6', 'SEED_DEMO:course:math6 - Củng cố số học và hình học.', 2400000
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE description = 'SEED_DEMO:course:math6 - Củng cố số học và hình học.');
INSERT INTO courses (name, description, fee)
SELECT 'Toán luyện thi khối 9', 'SEED_DEMO:course:math9 - Ôn thi vào lớp 10.', 3600000
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE description = 'SEED_DEMO:course:math9 - Ôn thi vào lớp 10.');
INSERT INTO courses (name, description, fee)
SELECT 'Tiếng Anh giao tiếp khối 7', 'SEED_DEMO:course:english7 - Từ vựng, nghe và giao tiếp.', 2800000
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE description = 'SEED_DEMO:course:english7 - Từ vựng, nghe và giao tiếp.');
INSERT INTO courses (name, description, fee)
SELECT 'Vật lý nâng cao khối 10', 'SEED_DEMO:course:physics10 - Cơ học và bài tập vận dụng.', 4000000
WHERE NOT EXISTS (SELECT 1 FROM courses WHERE description = 'SEED_DEMO:course:physics10 - Cơ học và bài tập vận dụng.');

INSERT INTO classes (course_id, teacher_id, name, description, status)
SELECT c.id, u.id, 'Toán 6A - nhóm nền tảng', 'SEED_DEMO:class:math6', 'active'
FROM courses c CROSS JOIN users u
WHERE c.description = 'SEED_DEMO:course:math6 - Củng cố số học và hình học.' AND u.email = 'demo.tutor.long@hoamatoan.vn'
  AND NOT EXISTS (SELECT 1 FROM classes WHERE description = 'SEED_DEMO:class:math6');
INSERT INTO classes (course_id, teacher_id, name, description, status)
SELECT c.id, u.id, 'Toán 9A - ôn thi vào 10', 'SEED_DEMO:class:math9', 'active'
FROM courses c CROSS JOIN users u
WHERE c.description = 'SEED_DEMO:course:math9 - Ôn thi vào lớp 10.' AND u.email = 'demo.tutor.long@hoamatoan.vn'
  AND NOT EXISTS (SELECT 1 FROM classes WHERE description = 'SEED_DEMO:class:math9');
INSERT INTO classes (course_id, teacher_id, name, description, status)
SELECT c.id, u.id, 'Tiếng Anh 7B', 'SEED_DEMO:class:english7', 'active'
FROM courses c CROSS JOIN users u
WHERE c.description = 'SEED_DEMO:course:english7 - Từ vựng, nghe và giao tiếp.' AND u.email = 'demo.tutor.mai@hoamatoan.vn'
  AND NOT EXISTS (SELECT 1 FROM classes WHERE description = 'SEED_DEMO:class:english7');
INSERT INTO classes (course_id, teacher_id, name, description, status)
SELECT c.id, u.id, 'Vật lý 10A', 'SEED_DEMO:class:physics10', 'planned'
FROM courses c CROSS JOIN users u
WHERE c.description = 'SEED_DEMO:course:physics10 - Cơ học và bài tập vận dụng.' AND u.email = 'demo.tutor.minh@hoamatoan.vn'
  AND NOT EXISTS (SELECT 1 FROM classes WHERE description = 'SEED_DEMO:class:physics10');

-- 4. Recurring weekly schedules; all values match the schema enums and TIME columns.
INSERT INTO schedules (class_id, day_of_week, start_time, end_time, starts_on, ends_on, location, status)
SELECT c.id, d.day_of_week, d.start_time, d.end_time, '2026-11-01', '2026-11-30', d.location, 'active'
FROM classes c
JOIN (
  SELECT 'SEED_DEMO:class:math6' AS marker, 'monday' AS day_of_week, '16:00:00' AS start_time, '17:30:00' AS end_time, 'Phòng 601' AS location
  UNION ALL SELECT 'SEED_DEMO:class:math6', 'wednesday', '16:00:00', '17:30:00', 'Phòng 601'
  UNION ALL SELECT 'SEED_DEMO:class:math6', 'friday', '16:00:00', '17:30:00', 'Phòng 601'
  UNION ALL SELECT 'SEED_DEMO:class:math9', 'tuesday', '18:00:00', '19:30:00', 'Phòng 902'
  UNION ALL SELECT 'SEED_DEMO:class:math9', 'thursday', '18:00:00', '19:30:00', 'Phòng 902'
  UNION ALL SELECT 'SEED_DEMO:class:english7', 'wednesday', '17:00:00', '18:30:00', 'Phòng 703'
  UNION ALL SELECT 'SEED_DEMO:class:english7', 'saturday', '09:00:00', '10:30:00', 'Phòng 703'
  UNION ALL SELECT 'SEED_DEMO:class:physics10', 'monday', '18:00:00', '19:30:00', 'Phòng 1002'
  UNION ALL SELECT 'SEED_DEMO:class:physics10', 'friday', '18:00:00', '19:30:00', 'Phòng 1002'
) d ON c.description = d.marker
WHERE NOT EXISTS (
  SELECT 1 FROM schedules s
  WHERE s.class_id = c.id AND s.day_of_week = d.day_of_week
    AND s.start_time = d.start_time AND s.starts_on = '2026-11-01'
);

-- 5. Class enrollments.
INSERT INTO enrollments (student_id, class_id, status)
SELECT s.id, c.id, 'active'
FROM students s CROSS JOIN classes c
WHERE s.notes = 'SEED_DEMO:student:an' AND c.description = 'SEED_DEMO:class:math6'
ON DUPLICATE KEY UPDATE status = VALUES(status);
INSERT INTO enrollments (student_id, class_id, status)
SELECT s.id, c.id, 'active'
FROM students s CROSS JOIN classes c
WHERE s.notes = 'SEED_DEMO:student:binh' AND c.description = 'SEED_DEMO:class:math6'
ON DUPLICATE KEY UPDATE status = VALUES(status);
INSERT INTO enrollments (student_id, class_id, status)
SELECT s.id, c.id, 'active'
FROM students s CROSS JOIN classes c
WHERE s.notes = 'SEED_DEMO:student:khoa' AND c.description = 'SEED_DEMO:class:math6'
ON DUPLICATE KEY UPDATE status = VALUES(status);
INSERT INTO enrollments (student_id, class_id, status)
SELECT s.id, c.id, 'active'
FROM students s CROSS JOIN classes c
WHERE s.notes = 'SEED_DEMO:student:chi' AND c.description = 'SEED_DEMO:class:math9'
ON DUPLICATE KEY UPDATE status = VALUES(status);
INSERT INTO enrollments (student_id, class_id, status)
SELECT s.id, c.id, 'active'
FROM students s CROSS JOIN classes c
WHERE s.notes = 'SEED_DEMO:student:duy' AND c.description = 'SEED_DEMO:class:english7'
ON DUPLICATE KEY UPDATE status = VALUES(status);
INSERT INTO enrollments (student_id, class_id, status)
SELECT s.id, c.id, 'active'
FROM students s CROSS JOIN classes c
WHERE s.notes = 'SEED_DEMO:student:linh' AND c.description = 'SEED_DEMO:class:physics10'
ON DUPLICATE KEY UPDATE status = VALUES(status);

-- 6. Attendance reports on dates matching their weekly schedule.
INSERT INTO attendance_reports
  (enrollment_id, schedule_id, lesson_date, attendance_status, note, reported_by)
SELECT e.id, sc.id, d.lesson_date, d.attendance_status, d.note, u.id
FROM (
  SELECT 'SEED_DEMO:student:an' AS student_marker, 'SEED_DEMO:class:math6' AS class_marker, 'monday' AS weekday, '2026-11-02' AS lesson_date, 'present' AS attendance_status, 'Tiếp thu nhanh, hoàn thành bài tập tốt.' AS note
  UNION ALL SELECT 'SEED_DEMO:student:an', 'SEED_DEMO:class:math6', 'wednesday', '2026-11-04', 'present', 'Làm bài đầy đủ, cần luyện thêm bài hình học.'
  UNION ALL SELECT 'SEED_DEMO:student:an', 'SEED_DEMO:class:math6', 'friday', '2026-11-06', 'absent', 'Phụ huynh xin nghỉ có phép.'
  UNION ALL SELECT 'SEED_DEMO:student:binh', 'SEED_DEMO:class:math6', 'monday', '2026-11-02', 'present', 'Chủ động phát biểu, nắm chắc phép tính phân số.'
  UNION ALL SELECT 'SEED_DEMO:student:binh', 'SEED_DEMO:class:math6', 'wednesday', '2026-11-04', 'present', 'Thiếu một phần bài tập về nhà, đã được nhắc nhở.'
  UNION ALL SELECT 'SEED_DEMO:student:khoa', 'SEED_DEMO:class:math6', 'monday', '2026-11-02', 'present', 'Hoàn thành bài đúng hạn, tiến bộ về tính nhẩm.'
  UNION ALL SELECT 'SEED_DEMO:student:chi', 'SEED_DEMO:class:math9', 'tuesday', '2026-11-03', 'present', 'Giải phương trình chính xác, trình bày rõ ràng.'
  UNION ALL SELECT 'SEED_DEMO:student:chi', 'SEED_DEMO:class:math9', 'thursday', '2026-11-05', 'present', 'Cần phân bổ thời gian tốt hơn khi làm đề.'
  UNION ALL SELECT 'SEED_DEMO:student:duy', 'SEED_DEMO:class:english7', 'wednesday', '2026-11-04', 'present', 'Phát âm tốt, tích cực luyện hội thoại.'
  UNION ALL SELECT 'SEED_DEMO:student:duy', 'SEED_DEMO:class:english7', 'saturday', '2026-11-07', 'absent', 'Gia đình báo vắng trước buổi học.'
  UNION ALL SELECT 'SEED_DEMO:student:linh', 'SEED_DEMO:class:physics10', 'monday', '2026-11-02', 'present', 'Vận dụng tốt định luật Newton vào bài tập.'
  UNION ALL SELECT 'SEED_DEMO:student:linh', 'SEED_DEMO:class:physics10', 'friday', '2026-11-06', 'present', 'Cần ghi rõ đơn vị trong các bước tính.'
) d
JOIN students st ON st.notes = d.student_marker
JOIN classes c ON c.description = d.class_marker
JOIN enrollments e ON e.student_id = st.id AND e.class_id = c.id
JOIN schedules sc ON sc.class_id = c.id AND sc.day_of_week = d.weekday
JOIN users u ON u.email = CASE d.class_marker
  WHEN 'SEED_DEMO:class:math6' THEN 'demo.tutor.long@hoamatoan.vn'
  WHEN 'SEED_DEMO:class:math9' THEN 'demo.tutor.long@hoamatoan.vn'
  WHEN 'SEED_DEMO:class:english7' THEN 'demo.tutor.mai@hoamatoan.vn'
  ELSE 'demo.tutor.minh@hoamatoan.vn'
END
WHERE NOT EXISTS (
  SELECT 1 FROM attendance_reports ar
  WHERE ar.enrollment_id = e.id AND ar.schedule_id = sc.id AND ar.lesson_date = d.lesson_date
);

-- 7. Assignments, submissions, and academic grades.
INSERT INTO assignments (class_id, created_by, title, description, due_at, status)
SELECT c.id, u.id, d.title, d.description, d.due_at, d.status
FROM (
  SELECT 'SEED_DEMO:class:math6' AS marker, 'Bài tập phân số tuần 1' AS title, 'SEED_DEMO:assignment:math6-1 - 10 câu phân số.' AS description, '2026-11-10 20:00:00' AS due_at, 'published' AS status
  UNION ALL SELECT 'SEED_DEMO:class:math6', 'Ôn tập hình học cơ bản', 'SEED_DEMO:assignment:math6-2 - Góc và tam giác.', '2026-11-17 20:00:00', 'published'
  UNION ALL SELECT 'SEED_DEMO:class:math9', 'Đề luyện thi số 1', 'SEED_DEMO:assignment:math9-1 - Phương trình và hệ phương trình.', '2026-11-12 20:00:00', 'published'
  UNION ALL SELECT 'SEED_DEMO:class:math9', 'Đề luyện thi số 2', 'SEED_DEMO:assignment:math9-2 - Hàm số bậc hai.', '2026-11-19 20:00:00', 'draft'
  UNION ALL SELECT 'SEED_DEMO:class:english7', 'Speaking: My daily routine', 'SEED_DEMO:assignment:english7-1 - Ghi âm bài nói 2 phút.', '2026-11-14 20:00:00', 'published'
  UNION ALL SELECT 'SEED_DEMO:class:english7', 'Vocabulary unit 3', 'SEED_DEMO:assignment:english7-2 - Ôn từ vựng chủ đề trường học.', '2026-11-21 20:00:00', 'published'
  UNION ALL SELECT 'SEED_DEMO:class:physics10', 'Bài tập định luật Newton', 'SEED_DEMO:assignment:physics10-1 - Bài tập lực và chuyển động.', '2026-11-13 20:00:00', 'published'
  UNION ALL SELECT 'SEED_DEMO:class:physics10', 'Thực hành phân tích chuyển động', 'SEED_DEMO:assignment:physics10-2 - Báo cáo ngắn.', '2026-11-20 20:00:00', 'draft'
) d
JOIN classes c ON c.description = d.marker
JOIN users u ON u.email = CASE d.marker
  WHEN 'SEED_DEMO:class:math6' THEN 'demo.tutor.long@hoamatoan.vn'
  WHEN 'SEED_DEMO:class:math9' THEN 'demo.tutor.long@hoamatoan.vn'
  WHEN 'SEED_DEMO:class:english7' THEN 'demo.tutor.mai@hoamatoan.vn'
  ELSE 'demo.tutor.minh@hoamatoan.vn'
END
WHERE NOT EXISTS (
  SELECT 1 FROM assignments a
  WHERE a.class_id = c.id AND a.title = d.title AND a.description = d.description
);

INSERT INTO assignment_submissions
  (assignment_id, enrollment_id, submitted_at, content, score, feedback, status, graded_by, graded_at)
SELECT a.id, e.id, d.submitted_at, d.content, d.score, d.feedback, d.status,
  CASE WHEN d.status = 'graded' THEN tutor.id ELSE NULL END,
  d.graded_at
FROM (
  SELECT 'SEED_DEMO:class:math6' AS class_marker, 'Bài tập phân số tuần 1' AS title, 'SEED_DEMO:student:an' AS student_marker, '2026-11-09 18:00:00' AS submitted_at, 'Đã hoàn thành đủ 10 câu.' AS content, 92.00 AS score, 'Trình bày tốt.' AS feedback, 'graded' AS status, 'demo.tutor.long@hoamatoan.vn' AS tutor_email, '2026-11-09 19:00:00' AS graded_at
  UNION ALL SELECT 'SEED_DEMO:class:math6', 'Bài tập phân số tuần 1', 'SEED_DEMO:student:binh', '2026-11-09 18:10:00', 'Hoàn thành 8 câu, còn 2 câu bỏ trống.', 78.00, 'Xem lại phép quy đồng.', 'graded', 'demo.tutor.long@hoamatoan.vn', '2026-11-09 19:10:00'
  UNION ALL SELECT 'SEED_DEMO:class:math6', 'Bài tập phân số tuần 1', 'SEED_DEMO:student:khoa', NULL, NULL, NULL, NULL, 'not_submitted', 'demo.tutor.long@hoamatoan.vn', NULL
  UNION ALL SELECT 'SEED_DEMO:class:math9', 'Đề luyện thi số 1', 'SEED_DEMO:student:chi', '2026-11-08 17:00:00', 'Đã nộp lời giải đầy đủ.', 88.00, 'Cần rút gọn bước biến đổi.', 'graded', 'demo.tutor.long@hoamatoan.vn', '2026-11-09 09:00:00'
  UNION ALL SELECT 'SEED_DEMO:class:english7', 'Speaking: My daily routine', 'SEED_DEMO:student:duy', '2026-11-08 16:00:00', 'Bài ghi âm đã nộp.', 85.00, 'Phát âm rõ, luyện thêm trọng âm.', 'graded', 'demo.tutor.mai@hoamatoan.vn', '2026-11-09 09:30:00'
  UNION ALL SELECT 'SEED_DEMO:class:physics10', 'Bài tập định luật Newton', 'SEED_DEMO:student:linh', '2026-11-08 19:00:00', 'Đã gửi bài giải 5 câu.', NULL, NULL, 'submitted', 'demo.tutor.minh@hoamatoan.vn', NULL
) d
JOIN classes c ON c.description = d.class_marker
JOIN assignments a ON a.class_id = c.id AND a.title = d.title
JOIN students st ON st.notes = d.student_marker
JOIN enrollments e ON e.class_id = c.id AND e.student_id = st.id
JOIN users tutor ON tutor.email = d.tutor_email
WHERE 1 = 1
ON DUPLICATE KEY UPDATE
  submitted_at = VALUES(submitted_at),
  content = VALUES(content),
  score = VALUES(score),
  feedback = VALUES(feedback),
  status = VALUES(status),
  graded_by = VALUES(graded_by),
  graded_at = VALUES(graded_at);

INSERT INTO grades (enrollment_id, score, feedback, recorded_by, recorded_at)
SELECT e.id, d.score, d.feedback, tutor.id, d.recorded_at
FROM (
  SELECT 'SEED_DEMO:class:math6' AS class_marker, 'SEED_DEMO:student:an' AS student_marker, 92.00 AS score, 'Tiến bộ tốt ở phần phân số.' AS feedback, '2026-11-09 19:00:00' AS recorded_at, 'demo.tutor.long@hoamatoan.vn' AS tutor_email
  UNION ALL SELECT 'SEED_DEMO:class:math6', 'SEED_DEMO:student:binh', 78.00, 'Cần luyện thêm phép quy đồng.', '2026-11-09 19:10:00', 'demo.tutor.long@hoamatoan.vn'
  UNION ALL SELECT 'SEED_DEMO:class:math6', 'SEED_DEMO:student:khoa', 84.00, 'Tính toán nhanh, cần ghi lời giải rõ hơn.', '2026-11-09 19:20:00', 'demo.tutor.long@hoamatoan.vn'
  UNION ALL SELECT 'SEED_DEMO:class:math9', 'SEED_DEMO:student:chi', 88.00, 'Nắm chắc kiến thức, cần tối ưu thời gian.', '2026-11-09 19:30:00', 'demo.tutor.long@hoamatoan.vn'
  UNION ALL SELECT 'SEED_DEMO:class:english7', 'SEED_DEMO:student:duy', 85.00, 'Giao tiếp tự tin, cần mở rộng từ vựng.', '2026-11-09 19:40:00', 'demo.tutor.mai@hoamatoan.vn'
  UNION ALL SELECT 'SEED_DEMO:class:physics10', 'SEED_DEMO:student:linh', 91.00, 'Vận dụng công thức chính xác.', '2026-11-09 19:50:00', 'demo.tutor.minh@hoamatoan.vn'
) d
JOIN classes c ON c.description = d.class_marker
JOIN students st ON st.notes = d.student_marker
JOIN enrollments e ON e.class_id = c.id AND e.student_id = st.id
JOIN users tutor ON tutor.email = d.tutor_email
WHERE NOT EXISTS (
  SELECT 1 FROM grades g
  WHERE g.enrollment_id = e.id AND g.feedback = d.feedback
);

-- 8. CRM leads.
INSERT INTO leads (fullname, phone, email, status, assigned_to, created_at)
SELECT d.fullname, d.phone, d.email, d.status, u.id, d.created_at
FROM (
  SELECT 'Đặng Minh Đức' AS fullname, '0918000001' AS phone, 'lead.duc@example.vn' AS email, 'new' AS status, '2026-11-04 09:00:00' AS created_at
  UNION ALL SELECT 'Lê Thu Trang', '0918000002', 'lead.trang@example.vn', 'consulting', '2026-11-03 10:30:00'
  UNION ALL SELECT 'Phạm Quốc Huy', '0918000003', 'lead.huy@example.vn', 'converted', '2026-11-02 14:15:00'
  UNION ALL SELECT 'Nguyễn Bảo Ngọc', '0918000004', 'lead.ngoc@example.vn', 'new', '2026-11-06 11:00:00'
  UNION ALL SELECT 'Vũ Thành Công', '0918000005', 'lead.cong@example.vn', 'cancelled', '2026-11-01 16:20:00'
  UNION ALL SELECT 'Trần Hải Yến', '0918000006', 'lead.yen@example.vn', 'consulting', '2026-11-07 08:45:00'
) d
JOIN users u ON u.email = 'demo.sales@hoamatoan.vn'
WHERE NOT EXISTS (SELECT 1 FROM leads l WHERE l.email = d.email);

-- 9. Contracts, invoices, and payment records; balances match the invoice totals.
INSERT INTO contracts
  (student_id, class_id, contract_code, total_amount, paid_amount, payment_status, created_at)
SELECT st.id, c.id, d.contract_code, d.total_amount, d.paid_amount, d.payment_status, d.created_at
FROM (
  SELECT 'SEED_DEMO:student:an' AS student_marker, 'SEED_DEMO:class:math6' AS class_marker, 'DEMO-HD-001' AS contract_code, 2400000.00 AS total_amount, 1200000.00 AS paid_amount, 'partially_paid' AS payment_status, '2026-10-25 10:00:00' AS created_at
  UNION ALL SELECT 'SEED_DEMO:student:binh', 'SEED_DEMO:class:math6', 'DEMO-HD-002', 2400000.00, 2400000.00, 'paid', '2026-10-25 10:15:00'
  UNION ALL SELECT 'SEED_DEMO:student:khoa', 'SEED_DEMO:class:math6', 'DEMO-HD-003', 2400000.00, 0.00, 'unpaid', '2026-11-01 09:00:00'
  UNION ALL SELECT 'SEED_DEMO:student:chi', 'SEED_DEMO:class:math9', 'DEMO-HD-004', 3600000.00, 3600000.00, 'paid', '2026-10-20 09:00:00'
  UNION ALL SELECT 'SEED_DEMO:student:duy', 'SEED_DEMO:class:english7', 'DEMO-HD-005', 2800000.00, 1400000.00, 'partially_paid', '2026-10-28 11:00:00'
  UNION ALL SELECT 'SEED_DEMO:student:linh', 'SEED_DEMO:class:physics10', 'DEMO-HD-006', 4000000.00, 0.00, 'unpaid', '2026-11-02 12:00:00'
) d
JOIN students st ON st.notes = d.student_marker
JOIN classes c ON c.description = d.class_marker
WHERE 1 = 1
ON DUPLICATE KEY UPDATE
  total_amount = VALUES(total_amount),
  paid_amount = VALUES(paid_amount),
  payment_status = VALUES(payment_status);

INSERT INTO invoices (contract_id, invoice_number, amount_paid, payment_method, cashier_id, created_at)
SELECT c.id, d.invoice_number, d.amount_paid, d.payment_method, u.id, d.created_at
FROM (
  SELECT 'DEMO-HD-001' AS contract_code, 'DEMO-INV-001' AS invoice_number, 1200000.00 AS amount_paid, 'bank_transfer' AS payment_method, '2026-10-26 10:00:00' AS created_at
  UNION ALL SELECT 'DEMO-HD-002', 'DEMO-INV-002', 2400000.00, 'cash', '2026-10-26 10:15:00'
  UNION ALL SELECT 'DEMO-HD-004', 'DEMO-INV-003', 2000000.00, 'vietqr', '2026-10-21 11:00:00'
  UNION ALL SELECT 'DEMO-HD-004', 'DEMO-INV-004', 1600000.00, 'bank_transfer', '2026-10-30 15:00:00'
  UNION ALL SELECT 'DEMO-HD-005', 'DEMO-INV-005', 1400000.00, 'cash', '2026-10-29 12:00:00'
) d
JOIN contracts c ON c.contract_code = d.contract_code
JOIN users u ON u.email = 'demo.accountant@hoamatoan.vn'
WHERE 1 = 1
ON DUPLICATE KEY UPDATE
  amount_paid = VALUES(amount_paid),
  payment_method = VALUES(payment_method),
  cashier_id = VALUES(cashier_id);

INSERT INTO payments
  (invoice_id, amount, paid_at, method, transaction_reference, status)
SELECT i.id, d.amount, d.paid_at, d.method, d.transaction_reference, d.status
FROM (
  SELECT 'DEMO-INV-001' AS invoice_number, 1200000.00 AS amount, '2026-10-26 10:00:00' AS paid_at, 'bank_transfer' AS method, 'DEMO-TXN-001' AS transaction_reference, 'completed' AS status
  UNION ALL SELECT 'DEMO-INV-002', 2400000.00, '2026-10-26 10:15:00', 'cash', 'DEMO-TXN-002', 'completed'
  UNION ALL SELECT 'DEMO-INV-003', 2000000.00, '2026-10-21 11:00:00', 'vietqr', 'DEMO-TXN-003', 'completed'
  UNION ALL SELECT 'DEMO-INV-004', 1600000.00, '2026-10-30 15:00:00', 'bank_transfer', 'DEMO-TXN-004', 'completed'
  UNION ALL SELECT 'DEMO-INV-005', 1400000.00, '2026-10-29 12:00:00', 'cash', 'DEMO-TXN-005', 'completed'
) d
JOIN invoices i ON i.invoice_number = d.invoice_number
WHERE 1 = 1
ON DUPLICATE KEY UPDATE
  amount = VALUES(amount),
  paid_at = VALUES(paid_at),
  method = VALUES(method),
  status = VALUES(status);

-- 10. Customer requests, work tasks, and parent support tickets.
INSERT INTO customer_requests (user_id, type, description, status, created_at)
SELECT u.id, d.type, d.description, d.status, d.created_at
FROM (
  SELECT 'demo.parent.huong@hoamatoan.vn' AS email, 'class_change' AS type, 'SEED_DEMO: Xin đổi lịch học thứ Sáu sang cuối tuần.' AS description, 'pending' AS status, '2026-11-05 08:30:00' AS created_at
  UNION ALL SELECT 'demo.parent.nam@hoamatoan.vn', 'leave_request', 'SEED_DEMO: Xin phép nghỉ buổi học ngày 12/11.', 'processing', '2026-11-06 09:15:00'
  UNION ALL SELECT 'demo.parent.mai@hoamatoan.vn', 'complaint', 'SEED_DEMO: Nhờ trung tâm kiểm tra lịch học bù của con.', 'resolved', '2026-11-03 14:00:00'
) d
JOIN users u ON u.email = d.email
WHERE NOT EXISTS (
  SELECT 1 FROM customer_requests r WHERE r.user_id = u.id AND r.description = d.description
);

INSERT INTO tasks (title, description, due_date, status, assigned_to)
SELECT d.title, d.description, d.due_date, d.status, u.id
FROM (
  SELECT 'Gọi tư vấn phụ huynh tiềm năng' AS title, 'SEED_DEMO: Gọi lại lead Trang về lớp Toán 9.' AS description, '2026-11-10 10:00:00' AS due_date, 'pending' AS status, 'demo.sales@hoamatoan.vn' AS assignee
  UNION ALL SELECT 'Đối soát học phí tháng 11', 'SEED_DEMO: Đối soát các khoản thu qua VietQR.', '2026-11-12 17:00:00', 'pending', 'demo.accountant@hoamatoan.vn'
  UNION ALL SELECT 'Chuẩn bị đề ôn tập', 'SEED_DEMO: Hoàn thiện đề luyện thi số 2 cho lớp Toán 9.', '2026-11-11 20:00:00', 'pending', 'demo.tutor.long@hoamatoan.vn'
  UNION ALL SELECT 'Cập nhật lịch học bù', 'SEED_DEMO: Xác nhận lịch học bù với phụ huynh An.', '2026-11-08 12:00:00', 'completed', 'demo.manager@hoamatoan.vn'
) d
JOIN users u ON u.email = d.assignee
WHERE NOT EXISTS (SELECT 1 FROM tasks t WHERE t.description = d.description);

INSERT INTO support_tickets (parent_id, subject, description, status, created_at)
SELECT u.id, d.subject, d.description, d.status, d.created_at
FROM (
  SELECT 'demo.parent.huong@hoamatoan.vn' AS email, 'Hỏi về kết quả học tập' AS subject, 'SEED_DEMO: Xin gửi nhận xét mới nhất của hai con.' AS description, 'open' AS status, '2026-11-06 10:00:00' AS created_at
  UNION ALL SELECT 'demo.parent.nam@hoamatoan.vn', 'Xác nhận lịch học bù', 'SEED_DEMO: Nhờ xác nhận lịch học bù cho học sinh Chi.', 'in_progress', '2026-11-07 11:30:00'
  UNION ALL SELECT 'demo.parent.mai@hoamatoan.vn', 'Hỏi về học phí', 'SEED_DEMO: Đã nhận được hướng dẫn thanh toán học phí.', 'resolved', '2026-11-04 15:30:00'
) d
JOIN users u ON u.email = d.email
WHERE NOT EXISTS (
  SELECT 1 FROM support_tickets t WHERE t.parent_id = u.id AND t.description = d.description
);

COMMIT;

-- Log in with any account below; all use Demo123456!
-- Admin:      demo.admin@hoamatoan.vn
-- Manager:    demo.manager@hoamatoan.vn
-- Sales:      demo.sales@hoamatoan.vn
-- Accountant: demo.accountant@hoamatoan.vn
-- Tutors:     demo.tutor.long@hoamatoan.vn / demo.tutor.mai@hoamatoan.vn / demo.tutor.minh@hoamatoan.vn
-- Parents:    demo.parent.huong@hoamatoan.vn / demo.parent.nam@hoamatoan.vn / demo.parent.mai@hoamatoan.vn
-- Students:   demo.student.an@hoamatoan.vn / demo.student.binh@hoamatoan.vn / demo.student.chi@hoamatoan.vn
--             demo.student.duy@hoamatoan.vn / demo.student.linh@hoamatoan.vn / demo.student.khoa@hoamatoan.vn
