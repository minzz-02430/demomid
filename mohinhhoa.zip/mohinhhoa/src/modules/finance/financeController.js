const financeService = require('./financeService');

const PAYMENT_METHODS = new Set(['cash', 'bank_transfer', 'vietqr', 'other']);

function isPositiveInteger(value) {
  return Number.isSafeInteger(value) && value > 0;
}

function normalizeAmount(value) {
  if (typeof value !== 'number' && typeof value !== 'string') {
    return null;
  }

  const amount = String(value).trim();
  if (!/^(?:0|[1-9]\d{0,9})(?:\.\d{1,2})?$/.test(amount)) {
    return null;
  }

  const [whole, fraction = ''] = amount.split('.');
  const cents = Number(whole) * 100 + Number(fraction.padEnd(2, '0'));
  if (!Number.isSafeInteger(cents) || cents <= 0) {
    return null;
  }

  return `${whole}.${fraction.padEnd(2, '0')}`;
}

async function createInvoice(req, res, next) {
  const { contractId, amountPaid, paymentMethod } = req.body ?? {};

  if (!isPositiveInteger(contractId)) {
    return res.status(400).json({
      status: 'error',
      message: 'contractId phải là số nguyên dương',
    });
  }

  const normalizedAmount = normalizeAmount(amountPaid);
  if (!normalizedAmount) {
    return res.status(400).json({
      status: 'error',
      message: 'amountPaid phải là số tiền dương, tối đa 2 chữ số thập phân',
    });
  }

  if (!PAYMENT_METHODS.has(paymentMethod)) {
    return res.status(400).json({
      status: 'error',
      message: "paymentMethod phải là 'cash', 'bank_transfer', 'vietqr' hoặc 'other'",
    });
  }

  try {
    const invoice = await financeService.createInvoice({
      contractId,
      amountPaid: normalizedAmount,
      paymentMethod,
      cashierId: req.user.id,
    });

    return res.status(201).json({
      status: 'success',
      message: 'Đã ghi nhận khoản thu học phí',
      data: { invoice },
    });
  } catch (error) {
    return next(error);
  }
}

async function getMonthlyRevenue(req, res, next) {
  try {
    const revenue = await financeService.getCurrentMonthRevenue();
    return res.status(200).json({
      status: 'success',
      totalRevenue: revenue.totalRevenue,
      month: revenue.month,
    });
  } catch (error) {
    return next(error);
  }
}

async function getDashboardKpis(req, res, next) {
  try {
    const kpis = await financeService.getDashboardKpis();

    return res.status(200).json({
      status: 'success',
      data: kpis,
    });
  } catch (error) {
    return next(error);
  }
}

async function getDashboardActivities(req, res, next) {
  try {
    const activities = await financeService.getDashboardActivities();

    return res.status(200).json({
      status: 'success',
      data: activities,
    });
  } catch (error) {
    return next(error);
  }
}

module.exports = {
  createInvoice,
  getMonthlyRevenue,
  getDashboardKpis,
  getDashboardActivities,
};
