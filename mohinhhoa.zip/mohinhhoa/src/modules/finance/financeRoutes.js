const express = require('express');
const { authenticateToken, requireRoles } = require('../../middlewares/authMiddleware');
const financeController = require('./financeController');

const router = express.Router();

router.post(
  '/invoices',
  authenticateToken,
  requireRoles('admin', 'accountant'),
  financeController.createInvoice,
);

router.get(
  '/dashboard/revenue',
  authenticateToken,
  requireRoles('admin', 'manager'),
  financeController.getMonthlyRevenue,
);

router.get(
  '/dashboard/kpis',
  authenticateToken,
  requireRoles('admin', 'manager'),
  financeController.getDashboardKpis,
);

router.get(
  '/dashboard/activities',
  authenticateToken,
  requireRoles('admin'),
  financeController.getDashboardActivities,
);

module.exports = router;
