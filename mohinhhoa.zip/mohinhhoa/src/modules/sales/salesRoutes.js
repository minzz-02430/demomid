const express = require('express');
const { authenticateToken, requireRoles } = require('../../middlewares/authMiddleware');
const salesController = require('./salesController');

const router = express.Router();

router.post(
  '/leads',
  authenticateToken,
  requireRoles('admin', 'sales'),
  salesController.createLead,
);

router.get(
  '/leads/my-queue',
  authenticateToken,
  requireRoles('sales'),
  salesController.getMyLeadQueue,
);

router.post(
  '/contracts',
  authenticateToken,
  requireRoles('admin', 'sales'),
  salesController.createContract,
);

module.exports = router;
