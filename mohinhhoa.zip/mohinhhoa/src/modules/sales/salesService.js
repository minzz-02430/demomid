const { randomBytes } = require('node:crypto');
const { pool } = require('../../config/db');

function createServiceError(message, statusCode) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

function generateContractCode() {
  return `CTR-${Date.now().toString(36).toUpperCase()}-${randomBytes(6).toString('hex').toUpperCase()}`;
}

async function createLead({ fullname, phone, email, status, assignedTo }) {
  if (assignedTo !== null) {
    const [assignees] = await pool.execute(
      'SELECT id FROM users WHERE id = ? AND role = ? LIMIT 1',
      [assignedTo, 'sales'],
    );

    if (assignees.length === 0) {
      throw createServiceError('Không tìm thấy tài khoản tư vấn viên được giao', 404);
    }
  }

  const [result] = await pool.execute(
    `INSERT INTO leads (fullname, phone, email, status, assigned_to)
     VALUES (?, ?, ?, ?, ?)`,
    [fullname, phone, email, status, assignedTo],
  );

  return {
    id: result.insertId,
    fullname,
    phone,
    email,
    status,
    assignedTo,
  };
}

async function getLeadQueue(salesUserId) {
  const [leads] = await pool.execute(
    `SELECT id, fullname, phone, email, status, assigned_to, created_at
     FROM leads
     WHERE assigned_to = ?
     ORDER BY created_at DESC, id DESC`,
    [salesUserId],
  );

  return leads;
}

async function createContract({ studentId, classId, totalAmount }) {
  const [matches] = await pool.execute(
    `SELECT s.id AS student_id, c.id AS class_id
     FROM students AS s
     CROSS JOIN classes AS c
     WHERE s.id = ? AND c.id = ?
     LIMIT 1`,
    [studentId, classId],
  );

  if (matches.length === 0) {
    throw createServiceError('Không tìm thấy học sinh hoặc lớp học', 404);
  }

  for (let attempt = 0; attempt < 5; attempt += 1) {
    const contractCode = generateContractCode();

    try {
      const [result] = await pool.execute(
        `INSERT INTO contracts
           (student_id, class_id, contract_code, total_amount, paid_amount, payment_status)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [studentId, classId, contractCode, totalAmount, 0, 'unpaid'],
      );

      return {
        id: result.insertId,
        studentId,
        classId,
        contractCode,
        totalAmount,
        paidAmount: 0,
        paymentStatus: 'unpaid',
      };
    } catch (error) {
      if (error.code !== 'ER_DUP_ENTRY') {
        throw error;
      }

      if (attempt === 4) {
        throw createServiceError('Không thể tạo mã hợp đồng duy nhất, vui lòng thử lại', 503);
      }
    }
  }

  throw createServiceError('Không thể tạo hợp đồng', 500);
}

module.exports = { createLead, getLeadQueue, createContract };
