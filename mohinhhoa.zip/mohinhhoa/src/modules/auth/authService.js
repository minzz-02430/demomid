const crypto = require('node:crypto');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool } = require('../../config/db');

const SALT_ROUNDS = 10;
const MAX_ATTEMPTS = 5;
const LOCK_MS = 15 * 60 * 1000;
const OTP_MS = 5 * 60 * 1000;

function createServiceError(message, statusCode) {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
}

function getJwtSecret() {
  if (!process.env.JWT_SECRET) {
    throw createServiceError('JWT_SECRET is not configured', 500);
  }

  return process.env.JWT_SECRET;
}

function passwordProblem(password) {
  if (typeof password !== 'string'
    || Buffer.byteLength(password, 'utf8') < 8
    || Buffer.byteLength(password, 'utf8') > 72
    || !/[a-zA-Z]/.test(password) || !/\d/.test(password)) {
    return 'Mật khẩu cần 8–72 ký tự, có cả chữ và số';
  }
  return null;
}

// Access token sống 15 phút; refresh token 7 ngày chỉ dùng để xin access token mới.
function issueTokens(user) {
  const tv = user.token_version ?? 0;
  return {
    token: jwt.sign({ id: user.id, email: user.email, role: user.role, tv }, getJwtSecret(), { expiresIn: '15m' }),
    refreshToken: jwt.sign({ id: user.id, tv, type: 'refresh' }, getJwtSecret(), { expiresIn: '7d' }),
  };
}

// shortcut: bộ đếm đăng nhập sai nằm trong bộ nhớ của một tiến trình; chạy nhiều tiến trình thì chuyển sang Redis hoặc bảng DB.
const failures = new Map();

function checkLocked(email) {
  const entry = failures.get(email);
  if (entry && entry.until > Date.now()) {
    throw createServiceError(`Đăng nhập sai quá ${MAX_ATTEMPTS} lần, thử lại sau ${Math.ceil((entry.until - Date.now()) / 60000)} phút`, 429);
  }
  if (entry && entry.until && entry.until <= Date.now()) failures.delete(email);
}

function recordFailure(email) {
  const entry = failures.get(email) || { count: 0, until: 0, first: Date.now() };
  if (Date.now() - entry.first > LOCK_MS) {
    entry.count = 0;
    entry.first = Date.now();
  }
  entry.count += 1;
  if (entry.count >= MAX_ATTEMPTS) entry.until = Date.now() + LOCK_MS;
  failures.set(email, entry);
}

async function register({ email, password, name, phone, role }) {
  const [existingUsers] = await pool.execute(
    'SELECT id FROM users WHERE email = ? LIMIT 1',
    [email],
  );

  if (existingUsers.length > 0) {
    throw createServiceError('Email đã được sử dụng', 409);
  }

  const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);

  try {
    const [result] = await pool.execute(
      `INSERT INTO users (role, name, email, phone, password_hash)
       VALUES (?, ?, ?, ?, ?)`,
      [role, name, email, phone, passwordHash],
    );

    return {
      id: result.insertId,
      name,
      email,
      phone,
      role,
    };
  } catch (error) {
    if (error.code === 'ER_DUP_ENTRY') {
      throw createServiceError('Email đã được sử dụng', 409);
    }

    throw error;
  }
}

async function login({ email, password }) {
  checkLocked(email);

  const [users] = await pool.execute(
    `SELECT id, name, email, phone, role, password_hash, branch, status, must_change_password, token_version
     FROM users
     WHERE email = ?
     LIMIT 1`,
    [email],
  );

  const user = users[0];
  if (!user || !(await bcrypt.compare(password, user.password_hash))) {
    recordFailure(email);
    throw createServiceError('Email hoặc mật khẩu không chính xác', 401);
  }
  if (user.status === 'locked') {
    throw createServiceError('Tài khoản đã bị khóa. Vui lòng liên hệ Ban giám đốc', 403);
  }
  failures.delete(email);

  return {
    ...issueTokens(user),
    user: {
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      role: user.role,
      branch: user.branch ?? null,
      mustChangePassword: Boolean(user.must_change_password),
    },
  };
}

async function refresh(refreshToken) {
  let payload;
  try {
    payload = jwt.verify(refreshToken, getJwtSecret());
  } catch {
    throw createServiceError('Phiên đăng nhập đã hết hạn', 401);
  }
  if (payload.type !== 'refresh') throw createServiceError('Phiên đăng nhập đã hết hạn', 401);

  const [users] = await pool.execute(
    'SELECT id, email, role, branch, status, token_version FROM users WHERE id = ? LIMIT 1',
    [payload.id],
  );
  const user = users[0];
  if (!user || user.status === 'locked' || (payload.tv ?? 0) !== (user.token_version ?? 0)) {
    throw createServiceError('Phiên đăng nhập đã hết hạn', 401);
  }
  return issueTokens(user);
}

// Đăng xuất làm mất hiệu lực mọi token đã cấp cho tài khoản.
async function logout(userId) {
  await pool.execute('UPDATE users SET token_version = token_version + 1 WHERE id = ?', [userId]);
}

async function changePassword(userId, currentPassword, newPassword) {
  const problem = passwordProblem(newPassword);
  if (problem) throw createServiceError(problem, 400);

  const [users] = await pool.execute(
    'SELECT id, email, role, password_hash, token_version FROM users WHERE id = ? LIMIT 1',
    [userId],
  );
  const user = users[0];
  if (!user || !(await bcrypt.compare(String(currentPassword ?? ''), user.password_hash))) {
    throw createServiceError('Mật khẩu hiện tại không chính xác', 401);
  }

  await pool.execute(
    'UPDATE users SET password_hash = ?, must_change_password = 0, token_version = token_version + 1 WHERE id = ?',
    [await bcrypt.hash(newPassword, SALT_ROUNDS), userId],
  );
  return issueTokens({ ...user, token_version: (user.token_version ?? 0) + 1 });
}

// Quên mật khẩu: luôn trả lời như nhau để không lộ email nào có tài khoản.
async function requestOtp(email) {
  const [users] = await pool.execute('SELECT id FROM users WHERE email = ? LIMIT 1', [email]);
  if (!users[0]) return null;

  const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
  await pool.execute('DELETE FROM password_otps WHERE user_id = ?', [users[0].id]);
  await pool.execute(
    'INSERT INTO password_otps (user_id, code_hash, expires_at, attempts) VALUES (?, ?, ?, 0)',
    [users[0].id, await bcrypt.hash(code, SALT_ROUNDS), new Date(Date.now() + OTP_MS)],
  );
  // shortcut: chưa nối dịch vụ gửi email nên mã chỉ được ghi log ngoài môi trường production; nối SMTP trước khi chạy thật.
  if (process.env.NODE_ENV !== 'production') console.info(`[OTP demo] ${email}: ${code}`);
  return code;
}

async function resetWithOtp(email, code, newPassword) {
  const problem = passwordProblem(newPassword);
  if (problem) throw createServiceError(problem, 400);

  const [rows] = await pool.execute(
    `SELECT o.id, o.user_id, o.code_hash, o.expires_at, o.attempts
     FROM password_otps o JOIN users u ON u.id = o.user_id
     WHERE u.email = ? ORDER BY o.id DESC LIMIT 1`,
    [email],
  );
  const otp = rows[0];
  if (!otp || new Date(otp.expires_at).getTime() < Date.now()) {
    throw createServiceError('Mã OTP không đúng hoặc đã hết hạn', 400);
  }
  if (otp.attempts >= MAX_ATTEMPTS) {
    throw createServiceError('Nhập sai quá 5 lần. Vui lòng lấy mã mới', 429);
  }
  if (!(await bcrypt.compare(String(code ?? ''), otp.code_hash))) {
    await pool.execute('UPDATE password_otps SET attempts = attempts + 1 WHERE id = ?', [otp.id]);
    throw createServiceError('Mã OTP không đúng hoặc đã hết hạn', 400);
  }

  await pool.execute(
    'UPDATE users SET password_hash = ?, must_change_password = 0, token_version = token_version + 1 WHERE id = ?',
    [await bcrypt.hash(newPassword, SALT_ROUNDS), otp.user_id],
  );
  await pool.execute('DELETE FROM password_otps WHERE user_id = ?', [otp.user_id]);
}

module.exports = {
  SALT_ROUNDS,
  changePassword,
  createServiceError,
  login,
  logout,
  passwordProblem,
  refresh,
  register,
  requestOtp,
  resetWithOtp,
};
