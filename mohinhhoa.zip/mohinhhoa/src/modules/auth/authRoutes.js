const express = require('express');
const authController = require('./authController');
const { authenticateToken } = require('../../middlewares/authMiddleware');

const router = express.Router();

router.post('/register', authController.register);
router.post('/login', authController.login);
router.post('/refresh', authController.refresh);
router.post('/forgot', authController.forgot);
router.post('/verify-otp', authController.verifyOtp);
router.post('/logout', authenticateToken, authController.logout);
router.post('/change-password', authenticateToken, authController.changePassword);

module.exports = router;
