const supportService = require('./supportService');

const REQUEST_TYPES = new Set(['leave_request', 'class_change', 'complaint']);
const UPDATABLE_STATUSES = new Set(['processing', 'resolved']);

function isPositiveInteger(value) {
  return Number.isSafeInteger(value) && value > 0;
}

async function createRequest(req, res, next) {
  const { type, description } = req.body ?? {};

  if (!REQUEST_TYPES.has(type)) {
    return res.status(400).json({
      status: 'error',
      message: "type phải là 'leave_request', 'class_change' hoặc 'complaint'",
    });
  }

  if (typeof description !== 'string'
    || description.trim().length === 0
    || description.trim().length > 5000) {
    return res.status(400).json({
      status: 'error',
      message: 'description phải có từ 1 đến 5000 ký tự',
    });
  }

  try {
    const request = await supportService.createRequest({
      userId: req.user.id,
      type,
      description: description.trim(),
    });

    return res.status(201).json({
      status: 'success',
      message: 'Đã gửi yêu cầu hỗ trợ',
      data: { request },
    });
  } catch (error) {
    return next(error);
  }
}

async function getPendingRequests(req, res, next) {
  try {
    const requests = await supportService.getPendingRequests();
    return res.status(200).json({
      status: 'success',
      data: { requests },
    });
  } catch (error) {
    return next(error);
  }
}

async function updateRequestStatus(req, res, next) {
  const requestId = Number(req.params.id);
  const { status } = req.body ?? {};

  if (!isPositiveInteger(requestId)) {
    return res.status(400).json({
      status: 'error',
      message: 'id phải là số nguyên dương',
    });
  }

  if (!UPDATABLE_STATUSES.has(status)) {
    return res.status(400).json({
      status: 'error',
      message: "status chỉ được là 'processing' hoặc 'resolved'",
    });
  }

  try {
    const request = await supportService.updateRequestStatus(requestId, status);
    return res.status(200).json({
      status: 'success',
      message: 'Đã cập nhật trạng thái yêu cầu',
      data: { request },
    });
  } catch (error) {
    return next(error);
  }
}

module.exports = { createRequest, getPendingRequests, updateRequestStatus };
