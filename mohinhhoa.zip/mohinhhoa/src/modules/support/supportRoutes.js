const express = require('express');
const { authenticateToken, requireRoles } = require('../../middlewares/authMiddleware');
const supportController = require('./supportController');

const router = express.Router();

router.post(
  '/requests',
  authenticateToken,
  requireRoles('parent', 'student'),
  supportController.createRequest,
);

router.get(
  '/requests/pending',
  authenticateToken,
  requireRoles('admin', 'manager'),
  supportController.getPendingRequests,
);

router.patch(
  '/requests/:id/status',
  authenticateToken,
  requireRoles('admin', 'manager'),
  supportController.updateRequestStatus,
);

module.exports = router;
