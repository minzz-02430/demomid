const express = require('express');
const { authenticateToken, requireRoles } = require('../../middlewares/authMiddleware');
const reportController = require('./reportController');

const router = express.Router();

router.post(
  '/session',
  authenticateToken,
  requireRoles('tutor'),
  reportController.createSessionReport,
);

router.get(
  '/my-children',
  authenticateToken,
  requireRoles('parent'),
  reportController.getMyChildrenReports,
);

router.get(
  '/tutor/classes',
  authenticateToken,
  requireRoles('tutor'),
  reportController.getTutorClasses,
);

router.get(
  '/tutor/schedules',
  authenticateToken,
  requireRoles('tutor'),
  reportController.getTutorSchedules,
);

module.exports = router;
