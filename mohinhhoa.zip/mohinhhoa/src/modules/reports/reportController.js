const reportService = require('./reportService');

const ATTENDANCE_STATUSES = new Set(['present', 'absent']);

function isPositiveInteger(value) {
  return Number.isSafeInteger(value) && value > 0;
}

function isValidDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) {
    return false;
  }

  const date = new Date(`${value}T00:00:00.000Z`);
  return !Number.isNaN(date.getTime()) && date.toISOString().slice(0, 10) === value;
}

async function createSessionReport(req, res, next) {
  const {
    scheduleId,
    enrollmentId,
    lessonDate,
    attendanceStatus,
    tutorComment,
  } = req.body ?? {};

  if (!isPositiveInteger(scheduleId) || !isPositiveInteger(enrollmentId)) {
    return res.status(400).json({
      status: 'error',
      message: 'scheduleId và enrollmentId phải là số nguyên dương',
    });
  }

  if (!isValidDate(lessonDate)) {
    return res.status(400).json({
      status: 'error',
      message: 'lessonDate phải có định dạng ngày hợp lệ YYYY-MM-DD',
    });
  }

  if (!ATTENDANCE_STATUSES.has(attendanceStatus)) {
    return res.status(400).json({
      status: 'error',
      message: "attendanceStatus chỉ được là 'present' hoặc 'absent'",
    });
  }

  if (typeof tutorComment !== 'string' || tutorComment.trim().length > 500) {
    return res.status(400).json({
      status: 'error',
      message: 'tutorComment phải là chuỗi không vượt quá 500 ký tự',
    });
  }

  try {
    const report = await reportService.createSessionReport({
      tutorId: req.user.id,
      scheduleId,
      enrollmentId,
      lessonDate,
      attendanceStatus,
      tutorComment: tutorComment.trim(),
    });

    return res.status(201).json({
      status: 'success',
      message: 'Đã lưu báo cáo buổi học',
      data: { report },
    });
  } catch (error) {
    return next(error);
  }
}

async function getMyChildrenReports(req, res, next) {
  try {
    const reports = await reportService.getReportsForParent(req.user.id);

    return res.status(200).json({
      status: 'success',
      data: { reports },
    });
  } catch (error) {
    return next(error);
  }
}

async function getTutorClasses(req, res, next) {
  try {
    const classes = await reportService.getTutorClasses(req.user.id);

    return res.status(200).json({
      status: 'success',
      data: classes,
    });
  } catch (error) {
    return next(error);
  }
}

async function getTutorSchedules(req, res, next) {
  try {
    const schedules = await reportService.getTutorSchedules(req.user.id);

    return res.status(200).json({
      status: 'success',
      data: schedules,
    });
  } catch (error) {
    return next(error);
  }
}

module.exports = {
  createSessionReport,
  getMyChildrenReports,
  getTutorClasses,
  getTutorSchedules,
};
