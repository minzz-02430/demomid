require('dotenv').config();

const mysql = require('mysql2/promise');

// Đảm bảo các dòng gán cấu hình trỏ thẳng vào process.env như thế này:
const pool = mysql.createPool({
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER,        // XÓA BỎ đoạn "|| 'your_mysql_user'" nếu có ở đây
  password: process.env.DB_PASSWORD,// XÓA BỎ đoạn "|| 'your_password'" nếu có ở đây
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: Number(process.env.DB_CONNECTION_LIMIT) || 10,
  queueLimit: 0,
});


async function connectDatabase() {
  let connection;

  try {
    connection = await pool.getConnection();
    console.info(`MySQL database connection established: ${process.env.DB_NAME}`);
  } catch (error) {
    console.error('Failed to connect to the MySQL database:', error);
    throw error;
  } finally {
    if (connection) {
      connection.release();
    }
  }
}

module.exports = { pool, connectDatabase };
