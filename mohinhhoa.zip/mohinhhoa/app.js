require('dotenv').config();

const path = require('node:path');
const express = require('express');
const cors = require('cors');
const { connectDatabase } = require('./src/config/db');
const authRoutes = require('./src/modules/auth/authRoutes');
const reportRoutes = require('./src/modules/reports/reportRoutes');
const salesRoutes = require('./src/modules/sales/salesRoutes');
const financeRoutes = require('./src/modules/finance/financeRoutes');
const supportRoutes = require('./src/modules/support/supportRoutes');
const platformRoutes = require('./src/modules/platform/platformRoutes');

const app = express();
const PORT = Number(process.env.PORT) || 3000;

app.use(cors(process.env.CORS_ORIGIN
  ? { origin: process.env.CORS_ORIGIN.split(',').map((item) => item.trim()), credentials: true }
  : undefined));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/reports', reportRoutes);
app.use('/api/v1/sales', salesRoutes);
app.use('/api/v1/finance', financeRoutes);
app.use('/api/v1/support', supportRoutes);

app.get('/api/v1', (req, res) => {
  res.status(200).json({
    status: 'OK',
    message: 'Hòa Ma Toán API v1',
    endpoints: {
      health: '/api/v1/health',
      auth: '/api/v1/auth',
      reports: '/api/v1/reports',
      sales: '/api/v1/sales',
      finance: '/api/v1/finance',
      support: '/api/v1/support',
    },
  });
});

app.get('/api/v1/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    message: 'Backend is running flawlessly',
  });
});

// Mount sau /api/v1 và /health vì mọi route trong này đều yêu cầu đăng nhập.
app.use('/api/v1', platformRoutes);

app.get('/', (req, res) => {
  res.redirect(302, '/test.html');
});

app.use(express.static(path.join(__dirname, 'public')));

app.use((err, req, res, next) => {
  if (res.headersSent) {
    return next(err);
  }

  const statusCode = Number.isInteger(err.statusCode) && err.statusCode >= 400 && err.statusCode < 600
    ? err.statusCode
    : Number.isInteger(err.status) && err.status >= 400 && err.status < 600
      ? err.status
      : 500;

  if (statusCode >= 500) console.error('Unhandled application error:', err);

  return res.status(statusCode).json({
    status: 'error',
    message: statusCode === 500 ? 'Internal server error' : err.message,
  });
});

async function startServer() {
  let startupStep = 'database';

  try {
    await connectDatabase();

    startupStep = 'http server';
    await new Promise((resolve, reject) => {
      const server = app.listen(PORT);
      server.once('error', reject);
      server.once('listening', () => {
        server.removeListener('error', reject);
        resolve();
      });
    });

    console.log(`Backend is running at http://localhost:${PORT}`);
  } catch (error) {
    if (startupStep === 'database') {
      console.error('[CRITICAL] Kết nối cơ sở dữ liệu thất bại!', error);
    } else {
      console.error('[CRITICAL] Khởi động HTTP server thất bại!', error);
    }

    process.exit(1);
  }
}

if (process.env.NODE_ENV !== 'test') {
  startServer();
}

module.exports = app;
