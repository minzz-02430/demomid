# Use case tổng thể — Hòa Ma Toán

Sơ đồ dùng ký pháp UML: actor ở ngoài ranh giới hệ thống, use case hình oval ở bên trong. Các vai trò kế thừa actor **Người dùng** để dùng chung chức năng đăng nhập.

![Sơ đồ use case Hòa Ma Toán](./usecase.svg)

`include` biểu thị bước bắt buộc: cập nhật kết quả cần lưu kết quả; thanh toán cần hiển thị mã VietQR. `extend` biểu thị thao tác tùy chọn: xuất báo cáo khi xem báo cáo, hoặc nhắc phí khi theo dõi học phí.

Mở file `usecase.svg` trực tiếp trong VS Code hoặc trình duyệt để xem phóng to.
