// Kiểm thử phân quyền theo bản audit (Prompt 12). Dùng MySQL giả trong bộ nhớ, không cần database thật.
const assert = require('node:assert/strict');
const test = require('node:test');
const bcrypt = require('bcryptjs');

process.env.JWT_SECRET = 'authz-test-secret';
process.env.NODE_ENV = 'test';

const { pool } = require('../src/config/db');

const HASH = bcrypt.hashSync('matkhau2026', 4);
const user = (id, role, branch, email) => ({ id, role, branch, email, name: email, phone: null, status: 'active', must_change_password: 0, token_version: 0, password_hash: HASH });
const db = {
  users: [
    user(1, 'admin', null, 'admin@hmt.vn'), user(10, 'manager', 'A', 'quanly.a@hmt.vn'), user(11, 'manager', 'B', 'quanly.b@hmt.vn'),
    user(9, 'accountant', 'A', 'ketoan@hmt.vn'), user(5, 'tutor', 'A', 'giaovien@hmt.vn'),
    user(30, 'parent', 'A', 'phuhuynh@hmt.vn'), user(31, 'parent', 'B', 'phuhuynh.khac@hmt.vn'),
  ],
  parentStudent: [{ parent_id: 30, student_id: 100 }, { parent_id: 31, student_id: 101 }],
  invoices: [
    { id: 500, invoice_number: 'HD-500', amount_paid: '2300000.00', status: 'awaiting', student_id: 100, student_name: 'Lê Minh Anh', branch: 'A' },
    { id: 501, invoice_number: 'HD-501', amount_paid: '3000000.00', status: 'pending', student_id: 101, student_name: 'Vũ Bảo Châu', branch: 'B' },
  ],
  otps: [], notifications: [], tasks: [], threads: [], members: [], messages: [], audit: [],
};
const byId = (id) => db.users.find((item) => item.id === Number(id));

pool.execute = async (sql, params = []) => {
  const has = (part) => sql.includes(part);
  if (has('token_version FROM users WHERE id = ?') || has('SELECT id, role, branch FROM users WHERE id') || has('SELECT id, branch FROM users WHERE id = ?')) return [[byId(params[0])].filter(Boolean).map((item) => ({ ...item }))];
  if (has('SELECT id, branch FROM users WHERE id IN')) return [db.users.filter((item) => params.includes(item.id))];
  if (has('SELECT id FROM users WHERE email')) return [db.users.filter((item) => item.email === params[0])];
  if (has('SELECT id, name, email, phone, role, password_hash')) return [db.users.filter((item) => item.email === params[0])];
  if (has('INSERT INTO users (role, name, email, phone, password_hash, branch')) {
    const [role, name, email, phone, hash, branch, status] = params;
    db.users.push({ ...user(200 + db.users.length, role, branch, email), name, phone, password_hash: hash, status, must_change_password: 1 });
    return [{ insertId: db.users.at(-1).id }];
  }
  if (has('INSERT INTO users')) {
    db.users.push({ ...user(300 + db.users.length, params[0], null, params[2]), password_hash: params[4] });
    return [{ insertId: db.users.at(-1).id }];
  }
  if (has('UPDATE users SET status')) {
    const target = byId(params[2]);
    if (target) Object.assign(target, { status: params[0], token_version: target.token_version + params[1] });
    return [{ affectedRows: target ? 1 : 0 }];
  }
  if (has('UPDATE users SET token_version')) { byId(params[0]).token_version += 1; return [{ affectedRows: 1 }]; }
  if (has('UPDATE users SET password_hash')) {
    const target = byId(params[1]);
    Object.assign(target, { password_hash: params[0], must_change_password: 0, token_version: target.token_version + 1 });
    return [{ affectedRows: 1 }];
  }
  if (has('DELETE FROM password_otps')) { db.otps = db.otps.filter((item) => item.user_id !== params[0]); return [{}]; }
  if (has('INSERT INTO password_otps')) { db.otps.push({ id: db.otps.length + 1, user_id: params[0], code_hash: params[1], expires_at: params[2], attempts: 0 }); return [{}]; }
  if (has('FROM password_otps o JOIN users')) return [db.otps.filter((item) => byId(item.user_id).email === params[0]).slice(-1)];
  if (has('UPDATE password_otps SET attempts')) { db.otps.find((item) => item.id === params[0]).attempts += 1; return [{}]; }
  if (has('INSERT INTO audit_log')) { db.audit.push(params[1]); return [{}]; }
  if (has('INSERT INTO notifications')) { db.notifications.push({ id: db.notifications.length + 1, user_id: params[0], type: params[1], title: params[2], is_read: 0 }); return [{ insertId: db.notifications.length }]; }
  if (has('FROM notifications WHERE user_id')) return [db.notifications.filter((item) => item.user_id === params[0])];
  if (has('UPDATE notifications SET is_read')) {
    const note = db.notifications.find((item) => item.id === params[0] && item.user_id === params[1]);
    if (note) note.is_read = 1;
    return [{ affectedRows: note ? 1 : 0 }];
  }
  if (has('FROM invoices i JOIN contracts')) {
    let rows = db.invoices;
    const rest = [...params];
    if (has('i.id = ?')) { const id = rest.shift(); rows = rows.filter((item) => item.id === id); }
    if (has('parent_student ps')) { const parent = rest.shift(); rows = rows.filter((item) => db.parentStudent.some((link) => link.parent_id === parent && link.student_id === item.student_id)); }
    if (has('s.branch = ?')) { const branch = rest.shift(); rows = rows.filter((item) => item.branch === branch); }
    return [rows];
  }
  if (has("UPDATE invoices SET status = 'paid'")) { db.invoices.find((item) => item.id === params[1]).status = 'paid'; return [{ affectedRows: 1 }]; }
  if (has('SELECT parent_id FROM parent_student')) return [db.parentStudent.filter((item) => item.student_id === params[0])];
  if (has('FROM tasks WHERE assigned_to')) return [db.tasks.filter((item) => [item.assigned_to, item.assigned_by].includes(params[0]))];
  if (has('INSERT INTO tasks')) { db.tasks.push({ id: db.tasks.length + 1, title: params[0], status: 'pending', assigned_to: params[4], assigned_by: params[5] }); return [{ insertId: db.tasks.length }]; }
  if (has('UPDATE tasks SET status')) {
    const task = db.tasks.find((item) => item.id === params[1] && [item.assigned_to, item.assigned_by].includes(params[2]));
    if (task) [task.status] = params;
    return [{ affectedRows: task ? 1 : 0 }];
  }
  if (has('INSERT INTO threads')) { db.threads.push({ id: db.threads.length + 1, title: params[0] }); return [{ insertId: db.threads.length }]; }
  if (has('INSERT INTO thread_members')) { db.members.push({ thread_id: params[0], user_id: params[1] }); return [{}]; }
  if (has('FROM thread_members WHERE thread_id = ? AND user_id = ? LIMIT 1')) return [db.members.filter((item) => item.thread_id === params[0] && item.user_id === params[1])];
  if (has('FROM thread_members WHERE thread_id = ? AND user_id <> ?')) return [db.members.filter((item) => item.thread_id === params[0] && item.user_id !== params[1])];
  if (has('INSERT INTO messages')) { db.messages.push({ id: db.messages.length + 1, thread_id: params[0], sender_id: params[1], body: params[2] }); return [{ insertId: db.messages.length }]; }
  if (has('UPDATE threads SET updated_at')) return [{}];
  if (has('FROM messages WHERE thread_id')) return [db.messages.filter((item) => item.thread_id === params[0])];
  if (has('FROM students s')) return [[{ id: 100, name: 'Lê Minh Anh', grade: 'Lớp 5', branch: 'A' }, { id: 101, name: 'Vũ, "Bảo" Châu', grade: 'Lớp 12', branch: 'B' }].filter((item) => !params[0] || item.branch === params[0])];
  throw new Error(`Unexpected SQL in authz test: ${sql}`);
};

const app = require('../app');

let server;
let base;
test.before(async () => {
  server = app.listen(0);
  await new Promise((resolve) => server.once('listening', resolve));
  base = `http://127.0.0.1:${server.address().port}/api/v1`;
});
test.after(() => server.close());

async function call(method, path, { body, token, cookie } = {}) {
  const response = await fetch(base + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(cookie ? { Cookie: cookie } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const type = response.headers.get('content-type') || '';
  return { status: response.status, body: type.includes('json') ? await response.json() : await response.text(), cookies: response.headers.getSetCookie() };
}
async function login(email, password = 'matkhau2026') {
  const result = await call('POST', '/auth/login', { body: { email, password } });
  assert.equal(result.status, 200, `login ${email}`);
  return result;
}
const tokenOf = async (email) => (await login(email)).body.data.token;

test('đăng ký công khai chỉ tạo được phụ huynh; token đặt trong cookie httpOnly', async () => {
  for (const role of ['tutor', 'manager', 'accountant']) {
    assert.equal((await call('POST', '/auth/register', { body: { email: `${role}@x.vn`, password: 'matkhau2026', name: 'X', role } })).status, 400);
  }
  assert.equal((await call('POST', '/auth/register', { body: { email: 'admin2@x.vn', password: 'matkhau2026', name: 'X', role: 'admin' } })).status, 403);

  const result = await login('phuhuynh@hmt.vn');
  const access = result.cookies.find((item) => item.startsWith('hmt_access='));
  assert.match(access, /HttpOnly/i);
  assert.match(access, /SameSite=Strict/i);
  // Trình duyệt chỉ cần cookie, không cần đọc token bằng JavaScript.
  assert.equal((await call('GET', '/notifications', { cookie: access.split(';')[0] })).status, 200);
  assert.equal((await call('GET', '/notifications')).status, 401);
});

test('phụ huynh gọi /admin/users nhận 403; chỉ admin cấp tài khoản, mật khẩu tạm buộc đổi', async () => {
  const body = { name: 'Phạm Thu Trang', email: 'thutrang@hmt.vn', role: 'tutor', branch: 'A' };
  assert.equal((await call('POST', '/admin/users', { body, token: await tokenOf('phuhuynh@hmt.vn') })).status, 403);
  assert.equal((await call('POST', '/admin/users', { body, token: await tokenOf('quanly.a@hmt.vn') })).status, 403);

  const admin = await tokenOf('admin@hmt.vn');
  assert.equal((await call('POST', '/admin/users', { body: { ...body, role: 'superuser' }, token: admin })).status, 400);
  assert.equal((await call('POST', '/admin/users', { body: { ...body, branch: '' }, token: admin })).status, 400);
  const created = await call('POST', '/admin/users', { body, token: admin });
  assert.equal(created.status, 201);
  assert.equal((await call('POST', '/admin/users', { body, token: admin })).status, 409);

  const first = await login('thutrang@hmt.vn', created.body.data.tempPassword);
  assert.equal(first.body.data.user.mustChangePassword, true);
  const weak = await call('POST', '/auth/change-password', { body: { currentPassword: created.body.data.tempPassword, newPassword: 'ngan' }, token: first.body.data.token });
  assert.equal(weak.status, 400);
  const changed = await call('POST', '/auth/change-password', { body: { currentPassword: created.body.data.tempPassword, newPassword: 'matkhaumoi2026' }, token: first.body.data.token });
  assert.equal(changed.status, 200);
  // Đổi mật khẩu xong thì token cũ mất hiệu lực, token mới dùng được.
  assert.equal((await call('GET', '/tasks', { token: first.body.data.token })).status, 403);
  assert.equal((await call('GET', '/tasks', { token: changed.body.data.token })).status, 200);

  // Khóa tài khoản: phiên đang mở bị ngắt và không đăng nhập lại được.
  const id = created.body.data.user.id;
  assert.equal((await call('PATCH', `/admin/users/${id}/status`, { body: { status: 'locked' }, token: admin })).status, 200);
  assert.equal((await call('GET', '/tasks', { token: changed.body.data.token })).status, 403);
  assert.equal((await call('POST', '/auth/login', { body: { email: 'thutrang@hmt.vn', password: 'matkhaumoi2026' } })).status, 403);
  assert.equal((await call('PATCH', '/admin/users/1/status', { body: { status: 'locked' }, token: admin })).status, 400);
});

test('quản lý cơ sở A đọc dữ liệu cơ sở B nhận 403; phụ huynh đọc con người khác nhận 404', async () => {
  const managerA = await tokenOf('quanly.a@hmt.vn');
  const own = await call('GET', '/invoices', { token: managerA });
  assert.deepEqual(own.body.data.invoices.map((item) => item.id), [500]);
  assert.equal((await call('GET', '/invoices?branch=B', { token: managerA })).status, 403);
  assert.equal((await call('GET', '/invoices/501', { token: managerA })).status, 404);
  assert.equal((await call('GET', '/export/students.csv?branch=B', { token: managerA })).status, 403);

  const parent = await tokenOf('phuhuynh@hmt.vn');
  assert.deepEqual((await call('GET', '/invoices', { token: parent })).body.data.invoices.map((item) => item.id), [500]);
  assert.equal((await call('GET', '/invoices/500', { token: parent })).status, 200);
  assert.equal((await call('GET', '/invoices/501', { token: parent })).status, 404);
  assert.equal((await call('GET', '/invoices', { token: await tokenOf('giaovien@hmt.vn') })).status, 403);
  assert.equal((await call('GET', '/invoices?branch=B', { token: await tokenOf('admin@hmt.vn') })).body.data.invoices.length, 1);
});

test('xác nhận thanh toán: đúng vai trò, đúng cơ sở, số tiền lấy từ DB', async () => {
  const body = { amount: 1, status: 'paid', branch: 'B' };
  assert.equal((await call('POST', '/invoices/500/confirm-payment', { body, token: await tokenOf('phuhuynh@hmt.vn') })).status, 403);
  assert.equal((await call('POST', '/invoices/500/confirm-payment', { body, token: await tokenOf('quanly.b@hmt.vn') })).status, 403);
  assert.equal((await call('POST', '/invoices/999/confirm-payment', { body, token: await tokenOf('ketoan@hmt.vn') })).status, 404);
  const confirmed = await call('POST', '/invoices/500/confirm-payment', { body, token: await tokenOf('ketoan@hmt.vn') });
  assert.equal(confirmed.status, 200);
  assert.equal(confirmed.body.data.amount, '2300000.00');
  assert.equal((await call('POST', '/invoices/500/confirm-payment', { token: await tokenOf('ketoan@hmt.vn') })).status, 409);
  // Phụ huynh của học viên nhận thông báo; phụ huynh khác thì không.
  const notes = await call('GET', '/notifications', { token: await tokenOf('phuhuynh@hmt.vn') });
  assert.ok(notes.body.data.notifications.some((item) => item.type === 'payment'));
  assert.equal((await call('GET', '/notifications', { token: await tokenOf('phuhuynh.khac@hmt.vn') })).body.data.notifications.length, 0);
  assert.equal((await call('PATCH', `/notifications/${notes.body.data.notifications[0].id}/read`, { token: await tokenOf('phuhuynh.khac@hmt.vn') })).status, 404);
});

test('giao việc và tin nhắn chỉ trong phạm vi được phép', async () => {
  const admin = await tokenOf('admin@hmt.vn');
  const managerA = await tokenOf('quanly.a@hmt.vn');
  assert.equal((await call('POST', '/tasks', { body: { title: 'Việc', assigneeId: 5 }, token: await tokenOf('giaovien@hmt.vn') })).status, 403);
  assert.equal((await call('POST', '/tasks', { body: { title: 'Việc', assigneeId: 5 }, token: admin })).status, 403); // admin giao cho quản lý
  assert.equal((await call('POST', '/tasks', { body: { title: 'Việc', assigneeId: 11 }, token: managerA })).status, 403); // khác cơ sở
  const task = await call('POST', '/tasks', { body: { title: 'Nộp đề giữa kỳ', assigneeId: 5, priority: 'high' }, token: managerA });
  assert.equal(task.status, 201);
  assert.equal((await call('PATCH', `/tasks/${task.body.data.id}`, { body: { status: 'doing' }, token: await tokenOf('quanly.b@hmt.vn') })).status, 404);
  assert.equal((await call('PATCH', `/tasks/${task.body.data.id}`, { body: { status: 'doing' }, token: await tokenOf('giaovien@hmt.vn') })).status, 200);

  assert.equal((await call('POST', '/threads', { body: { title: 'Trao đổi', participantIds: [11] }, token: managerA })).status, 403);
  const thread = await call('POST', '/threads', { body: { title: 'Lớp Toán 8', participantIds: [5] }, token: managerA });
  assert.equal(thread.status, 201);
  const path = `/threads/${thread.body.data.id}/messages`;
  assert.equal((await call('POST', path, { body: { body: 'Chào thầy' }, token: managerA })).status, 201);
  assert.equal((await call('GET', path, { token: await tokenOf('giaovien@hmt.vn') })).body.data.messages.length, 1);
  assert.equal((await call('GET', path, { token: await tokenOf('phuhuynh@hmt.vn') })).status, 404);
  assert.equal((await call('POST', path, { body: { body: 'Chen ngang' }, token: await tokenOf('quanly.b@hmt.vn') })).status, 404);
});

test('xuất CSV theo quyền và theo cơ sở', async () => {
  assert.equal((await call('GET', '/export/students.csv', { token: await tokenOf('phuhuynh@hmt.vn') })).status, 403);
  assert.equal((await call('GET', '/export/passwords.csv', { token: await tokenOf('admin@hmt.vn') })).status, 404);
  const mine = await call('GET', '/export/students.csv', { token: await tokenOf('quanly.a@hmt.vn') });
  assert.equal(mine.status, 200);
  assert.ok(mine.body.includes('Lê Minh Anh') && !mine.body.includes('Châu'));
  const all = await call('GET', '/export/students.csv', { token: await tokenOf('admin@hmt.vn') });
  assert.ok(all.body.includes('"Vũ, ""Bảo"" Châu"'));
});

test('đăng xuất vô hiệu token; refresh cấp token mới; OTP đúng mới đặt lại được mật khẩu', async () => {
  const session = await login('giaovien@hmt.vn');
  const refreshCookie = session.cookies.find((item) => item.startsWith('hmt_refresh=')).split(';')[0];
  assert.equal((await call('POST', '/auth/refresh', { cookie: refreshCookie })).status, 200);
  assert.equal((await call('GET', '/tasks', { token: refreshCookie.split('=')[1] })).status, 403); // refresh token không dùng làm access token
  assert.equal((await call('POST', '/auth/logout', { token: session.body.data.token })).status, 200);
  assert.equal((await call('GET', '/tasks', { token: session.body.data.token })).status, 403);
  assert.equal((await call('POST', '/auth/refresh', { cookie: refreshCookie })).status, 401);

  assert.equal((await call('POST', '/auth/forgot', { body: { email: 'khong-ton-tai@hmt.vn' } })).status, 200);
  assert.equal(db.otps.length, 0);
  assert.equal((await call('POST', '/auth/forgot', { body: { email: 'ketoan@hmt.vn' } })).status, 200);
  assert.equal(db.otps.length, 1);
  assert.equal((await call('POST', '/auth/verify-otp', { body: { email: 'ketoan@hmt.vn', code: 'abcdef', newPassword: 'matkhaumoi2026' } })).status, 400);
  db.otps[0].code_hash = bcrypt.hashSync('123456', 4);
  assert.equal((await call('POST', '/auth/verify-otp', { body: { email: 'ketoan@hmt.vn', code: '123456', newPassword: 'matkhaumoi2026' } })).status, 200);
  assert.equal((await call('POST', '/auth/login', { body: { email: 'ketoan@hmt.vn', password: 'matkhaumoi2026' } })).status, 200);
});

test('đăng nhập sai 5 lần bị chặn 15 phút', async () => {
  for (let attempt = 0; attempt < 5; attempt += 1) {
    assert.equal((await call('POST', '/auth/login', { body: { email: 'phuhuynh.khac@hmt.vn', password: 'sai-mat-khau' } })).status, 401);
  }
  assert.equal((await call('POST', '/auth/login', { body: { email: 'phuhuynh.khac@hmt.vn', password: 'matkhau2026' } })).status, 429);
});
